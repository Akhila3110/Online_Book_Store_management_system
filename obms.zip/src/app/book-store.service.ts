import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './Customer';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookStoreService {

  private baseUrl = "http://localhost:8120";
  httpService: any;
  constructor(private http: HttpClient) {}
  customer: Customer;
  validateCustomer(customerEmail: string, customerPassword: string): Observable<Customer> {
    return this.http.get<Customer>(
      this.baseUrl + "/Customer/validate/" + customerEmail + "/" + customerPassword
    );
  }
  AddCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(
      this.baseUrl + "/Customer/addCustomer",
      customer
    );
  }
  public getAllCustomers(){
    return this.http.get<Array<Customer>>("http://localhost:8120/Customer/all");
  }

  public updateCustomer(customerId:number,customer:Customer):Observable<Customer>
{
 return this.http.put<Customer>("http://localhost:8120/Customer/updateCustomer/"+customerId,customer);
}

  public deleteCustomer(customerId:number):Observable<Customer>{

    return this.http.delete<Customer>("http://localhost:8120/Customer/deleteCustomer/"+customerId);
  }

  public getCustomerById(customerId:Customer){

    return this.http.get<Customer>("http://localhost:8120/Customer/id/"+customerId);
}
}

 


