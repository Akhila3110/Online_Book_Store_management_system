import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from '@angular/router';
import { BookStoreService } from '../book-store.service';
import { Observable } from 'rxjs';
import { Customer } from "../customer";



@Component({
  selector: "app-customer-list",
  templateUrl: "./customer-list.component.html",
  styleUrls: ["./customer-list.component.css"],
})
export class CustomerListComponent implements OnInit {
  constructor(private bookStoreService:BookStoreService,private route:ActivatedRoute,private router:Router) { }
  customers:Array<Customer>;
  ngOnInit(): void {
    this.bookStoreService.getAllCustomers().subscribe(
      response=>this.handleSuccessfulResponse(response)
      
    );
      }
      handleSuccessfulResponse(response)
      {
        this.customers=response;
        console.log(this.customers)
      }
    //   delete(customerId: number) {
      
    //     if(confirm("Are you sure want to delete this id : "+customerId+" ?"))
    // {
    //   this.bookStoreService.deleteCustomer(customerId).subscribe((success)=>{"Deleted Successfully"},
    //   (error)=>{"Error:ID is deleted"});
    // }
    //   }
      goBack()
      {
            this.router.navigate(['/customer']);
      }
      
      
    
  

  }

