import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerComponent } from './customer/customer.component';
import { RegisterComponent } from './register/register.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { DeleteCustomerComponent } from './delete-customer/delete-customer.component';


const routes: Routes = [
  

  {
    path:"register", component:RegisterComponent
  },

  {
    path:"customer-login", component:CustomerLoginComponent
  },

  {
    path:"customer", component:CustomerComponent
  },

  {
    path:"customer/view-customer", component:ViewCustomerComponent
  },
  {
    path:"customer/update-customer", component:UpdateCustomerComponent
  },
  {
    path:"customer/delete-customer", component:DeleteCustomerComponent
  },

  {
    path : "customer/customer-list"  ,component :CustomerListComponent

  },
  
  {
    path:'customer/update-customer',component:UpdateCustomerComponent
  },
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
