import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  userName : string ="";
  userPass : string ="";

  constructor(private service : LoginService,private router : Router) { }

  ngOnInit(): void {
    let user =sessionStorage.getItem("userName");
    if(user !=null){
      alert(user+ ' already logged in ');
      this.router.navigate(['/booking']);
    }
  }

  validate()
  {
  this.service.validate(this.userName,this.userPass).subscribe(
    data => {
     sessionStorage.setItem("userRole",data); 
     sessionStorage.setItem("userName",this.userName);
    alert('Login Success ' + data);
    if(this.userName=="admin")
    {
    this.router.navigate(['/admin']);
    }
    else{
      this.router.navigate(['/product-master']);
    }
  },
  error =>{
    sessionStorage.clear();
    alert('Login failed')
  });
  }

}
