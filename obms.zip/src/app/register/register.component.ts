import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { BookStoreService } from '../book-store.service';
import { Router } from '@angular/router';
import { generate } from 'rxjs';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private bookStoreService:BookStoreService, private route:Router) { }
  customer:Customer;
  generatedId:number;
  ngOnInit(): void {
     this.customer=new Customer();
  }
  addCustomer(){
    console.log(this.customer);
this.bookStoreService.AddCustomer(this.customer).subscribe(
 
  (response)=>
      {
       this.generatedId =response.customerId;
        alert("Customer added successfully with "+this.generatedId+" customer Id");
         this.route.navigate(['/customer-login']);
      },
      (error)=>
      {
        alert("Failed to add Customer");
      }
);
  }
 
       
  


}
