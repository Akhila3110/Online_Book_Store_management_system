import { Component, OnInit } from '@angular/core';
import { Time } from '@angular/common';
import { Customer } from '../Customer';
import { BookStoreService } from '../book-store.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {

  customer:Customer;
  customerId:number;
  searchorderId=0;
  constructor(private  bookStoreService:BookStoreService, private router: ActivatedRoute,private route: Router,) { 
    this.customer=new Customer();
  }
  
  ngOnInit(): void {
    this.customer=new Customer();
    this.router.params.subscribe(param=>{
     this.searchorderId=param['id'];
    })
  }
  onClickSubmit(updateCustomer){
    this.bookStoreService.updateCustomer(updateCustomer.customerId,this.customer).subscribe(
     (success)=>{
     alert("Receipient details updated");
     },
   (error)=>
   {
     alert("Updated");
   }
   );
   }
   goBack()
{
      this.route.navigate(['/customer/customer-list']);
}

}


