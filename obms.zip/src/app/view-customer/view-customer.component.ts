import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { BookStoreService } from '../book-store.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {

  constructor(private bookStoreService:BookStoreService, private route:ActivatedRoute, private router:Router) { }
  customerId:number;
  customer:Customer;
  
  searchText:number;
  ngOnInit(): void {
  }
 getCustomer(){
   
  this.route.params.subscribe(param => {
    
        this.bookStoreService.getCustomerById(this.customer).subscribe(
          (response) => {
            this.customer = response;
           
           console.log(this.customer);
          }
          ,
          (error) => {
            alert("No OrderId with Number=" + this.searchText);
          }
        );
      })

}
goBack()
{
      this.router.navigate(['/customer']);
}
}
