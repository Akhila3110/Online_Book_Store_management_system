import { Component, OnInit } from '@angular/core';
import { BookStoreService } from '../book-store.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../Customer';

@Component({
  selector: 'app-delete-customer',
  templateUrl: './delete-customer.component.html',
  styleUrls: ['./delete-customer.component.css']
})
export class DeleteCustomerComponent implements OnInit {

  constructor(private  bookStoreService: BookStoreService,private router:ActivatedRoute,private route:Router) { }
  customer: Customer;
  customerId:number;
  ngOnInit(): void {
  }
  deleteCustomer(customerId:number){
        if(confirm("Sure to Delete?")){
          this.bookStoreService.deleteCustomer(customerId).subscribe(
            (success)=>{
                 alert("Customer with id ["+customerId+"] is Deleted");
                this.ngOnInit(); 
                },
            (error)=>{
              alert("No customer is available on this id to delete");
            }
          );
        }
      }
      goBack()
        {
              this.route.navigate(['/customer/customer-list']);
        }
}
