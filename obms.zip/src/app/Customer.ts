export class Customer{   
    public customerId:number;
	public customerName:string ;
	public customerEmail:string ;
	public customerPassword:string ;
	public phoneNumber:string ;
    public address:string;
    public city:string;
    public zipCode:string;
    public country:string;
 
}