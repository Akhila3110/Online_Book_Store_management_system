import { Component, OnInit } from '@angular/core';
import { BookStoreService } from '../book-store.service';
import { Customer } from '../Customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {
  customer: Customer = new Customer();
      
  constructor(private bookStoreService: BookStoreService, private router: Router) {}
  ngOnInit(): void {}

  validate() {
    this.bookStoreService.validateCustomer(
      this.customer.customerEmail,
      this.customer.customerPassword
    ).subscribe(
      (customer) => {
        console.log(customer);
        if (customer) {
          alert("login success!!");
          this.router.navigate(["/customer"]);
        } else {
          alert("login failed!!!");
        }
      },
      (error) => {
        alert("login failed!!!");
      }
    );
  }
}

